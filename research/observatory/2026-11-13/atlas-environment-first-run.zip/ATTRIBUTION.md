# Source attribution and use conditions

Contains information from NEA PM2.5 via data.gov.sg, accessed 2026-11-13T07:56:51.381812Z, from https://api-open.data.gov.sg/v2/real-time/api/pm25, made available under Singapore Open Data Licence 1.0: https://data.gov.sg/open-data-licence

Environmental observation and attributed derived research; no official endorsement.

