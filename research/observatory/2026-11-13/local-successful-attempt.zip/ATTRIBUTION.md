# Source attribution and use conditions

Contains information from NEA PM2.5 via data.gov.sg, accessed 2026-11-13T07:55:37.617729Z, from https://api-open.data.gov.sg/v2/real-time/api/pm25, made available under Singapore Open Data Licence 1.0: https://data.gov.sg/open-data-licence

Environmental observation and attributed derived research; no official endorsement.

Contains information from Binance Vision historical spot klines, accessed 2026-11-13T07:55:37.617729Z, from https://data.binance.vision/, made available under CC BY-NC-SA 4.0 and Binance Vision Dataset Terms: https://github.com/binance/binance-public-data/blob/master/TERMS_AND_CONDITIONS.md

Non-commercial research and education only; attributable derivatives retain CC BY-NC-SA 4.0. No commercial signals or live execution.

