# Source attribution and use conditions

Contains information from Binance Vision historical spot klines, accessed 2026-11-13T07:56:51.483742Z, from https://data.binance.vision/, made available under CC BY-NC-SA 4.0 and Binance Vision Dataset Terms: https://github.com/binance/binance-public-data/blob/master/TERMS_AND_CONDITIONS.md

Non-commercial research and education only; attributable derivatives retain CC BY-NC-SA 4.0. No commercial signals or live execution.

